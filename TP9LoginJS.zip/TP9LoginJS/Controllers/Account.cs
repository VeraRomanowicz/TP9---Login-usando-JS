using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using TP9LoginJS.Models;

namespace TP9LoginJS.Controllers;

public class Account : Controller
{
    public IActionResult ValidarUsuario (string correo, string contra)
    {

        if (BD.ValidarUsuarioBD (correo, contra) is null)
        {
            return View("Login");
        }
        else 
        {
            return View("PagBienvenida");
        }

    }

}