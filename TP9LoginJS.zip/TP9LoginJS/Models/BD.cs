using System.Data.SqlClient;
using Dapper;
namespace TPEjemplo.Models;

public class BD
{
    private static string _ConnectionString = "Server=localhost;DataBase=BDSeries;Trusted_Connection=true;";
    public static string ValidarUsuarioBD(string correo, string contra)
    {
        string usuario;
         using(SqlConnection conn = new SqlConnection(_ConnectionString)){
            string sql="SELECT Correo from Usuarios where Correo=@pcorreo and Contraseña=@pcontra)";
            usuario = conn.Query<string>(sql, new {pcontra = contra, pcorreo = correo});
        }
        return usuario;
    }

}