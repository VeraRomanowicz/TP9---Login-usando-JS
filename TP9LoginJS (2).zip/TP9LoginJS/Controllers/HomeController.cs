using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using TP9LoginJS.Models;

namespace TP9LoginJS.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Login(string error = "")
    {
        ViewBag.MensajeError = error;
        return View();
    }

    public IActionResult Registro(string error = "")
    {
        ViewBag.MensajeError = error;
        return View();
    }

    public IActionResult PagBienvenida()
    {
        return View();
    }

    public IActionResult Olvide(string error = "")
    {
        ViewBag.MensajeError = error;
        return View();
    }

}
