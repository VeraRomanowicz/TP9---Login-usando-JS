﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

function ValidarContraseña()
{
    const contra =  document.getElementById("contra");
    const contra2 =  document.getElementById("contra");

    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\W).{8,}$/;

    if (!regex.test(password)) {
        alert('La contraseña debe tener al menos 8 caracteres, una letra mayúscula y un carácter especial.');
        return false;
    }

    if (password !== confirmPassword) {
        alert('Las contraseñas no coinciden.');
        return false;
    }
    return true;
}